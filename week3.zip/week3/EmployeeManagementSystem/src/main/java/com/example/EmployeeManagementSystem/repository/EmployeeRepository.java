package com.example.EmployeeManagementSystem.repository;

import org.hibernate.mapping.List;

import com.example.EmployeeManagementSystem.model.Department;
import com.example.EmployeeManagementSystem.model.Employee;
import com.example.EmployeeManagementSystem.projection-ex8.EmployeeDTO;
import com.example.EmployeeManagementSystem.projection-ex8.EmployeeSummary;
import com.example.employeemanagementsystem.model.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

//ex6
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface  EmployeeRepository extends JpaRepository<Department, Long> {
    // // Derived query method to find employees by department name
    // List<Employee> findByDepartmentName(String departmentName);
    
    // // Derived query method to find employees by email
    // Employee findByEmail(String email);

    //Query method ex:5

    //custom query method
    @Query("SELECT e FROM Employee e WHERE e.department.name = :departmentName")
    List<Employee> findEmployeesByDepartmentName(@Param("departmentName") String departmentName);
    
    @Query("SELECT e FROM Employee e WHERE e.email = :email")
    Employee findEmployeeByEmail(@Param("email") String email);


    //ex6
    Page<Employee> findByDepartmentName(String departmentName, Pageable pageable);
    
    Page<Employee> findByNameContaining(String name, Pageable pageable);

    Page<Employee> findAll(Pageable pageable); // Default method for pagination and sorting

    //ex8
    @Query("SELECT new com.example.employeemanagementsystem.projection.EmployeeDTO(e.id, e.name, e.email) FROM Employee e")
    List<EmployeeDTO> findAllEmployeeDTOs();

    @Query("SELECT e FROM Employee e WHERE e.department.name = ?1")
    List<EmployeeSummary> findEmployeeSummariesByDepartmentName(String departmentName);
}
