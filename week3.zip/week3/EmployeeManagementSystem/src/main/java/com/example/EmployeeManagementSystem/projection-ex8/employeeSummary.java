package com.example.EmployeeManagementSystem.projection;

public interface EmployeeSummary {
    Long getId();
    String getName();
    String getEmail();
}
