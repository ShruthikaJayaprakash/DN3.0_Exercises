package com.library.repositary;
import org.springframework.stereotype.Repository;

@Repository
public class BookRepository {

}
