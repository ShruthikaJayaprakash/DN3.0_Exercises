package com.library.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.JoinPoint;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Aspect
public class LoggingAspect {

	private static final Logger LOGGER = LoggerFactory.getLogger(LoggingAspect.class.getName());
  @Before("execution(* *(..))")
  public void logBeforeMethodExecution(JoinPoint joinPoint) {
      LOGGER.info("Before executing method: {}", joinPoint.getSignature());
  }
  @Around("execution(* com.library..*(..))")
  public Object logExecutionTime(ProceedingJoinPoint joinPoint) throws Throwable {
    long start = System.currentTimeMillis();
    Object proceed = joinPoint.proceed();
    long executionTime = System.currentTimeMillis() - start;
    LOGGER.info("Method '{}' executed in {} ms", joinPoint.getSignature().getName(), executionTime);
    return proceed;
  }
  @After("execution(* *(..))")
  public void logAfterMethodExecution(JoinPoint joinPoint) {
      LOGGER.info("After executing method: {}", joinPoint.getSignature());
  }
}